package tierlist;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        TierManager manager = new TierManager();

        while (true) {
            System.out.println("\n=== TIER LIST MAKER ===");
            System.out.println("1. Tambah Item");
            System.out.println("2. Pindah Item");
            System.out.println("3. Tampilkan Tier");
            System.out.println("4. Keluar");
            System.out.print("Pilih menu: ");

            try {
                int menu = Integer.parseInt(sc.nextLine());

                if (menu == 1) {
                    System.out.print("Nama item: ");
                    String name = sc.nextLine();

                    System.out.print("Tier (S/A/B/C/D): ");
                    String tier = sc.nextLine();

                    Tier t = manager.getTier(tier);
                    if (t != null) {
                        t.addItem(new TierItem(name));
                        System.out.println("Item ditambahkan.");
                    } else {
                        System.out.println("Tier tidak valid.");
                    }

                } else if (menu == 2) {
                    System.out.print("Nama item: ");
                    String item = sc.nextLine();

                    System.out.print("Dari tier: ");
                    String from = sc.nextLine();

                    System.out.print("Ke tier: ");
                    String to = sc.nextLine();

                    if (manager.moveItem(item, from, to)) {
                        System.out.println("Item berhasil dipindah.");
                    } else {
                        System.out.println("Gagal memindah item.");
                    }

                } else if (menu == 3) {
                    manager.showAll();

                } else if (menu == 4) {
                    System.out.println("Program selesai.");
                    break;

                } else {
                    System.out.println("Menu tidak valid.");
                }

            } catch (Exception e) {
                System.out.println("Input harus angka!");
            }
        }

        sc.close();
    }
}
