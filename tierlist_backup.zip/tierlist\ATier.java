package tierlist;

public class ATier extends Tier {
    @Override
    public String getTierName() {
        return "A";
    }
}
