package tierlist;

public class STier extends Tier {
    @Override
    public String getTierName() {
        return "S";
    }
}
