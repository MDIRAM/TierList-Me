package tierlist;

public class TierItem {
    private String name;

    public TierItem(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
