package tierlist;

public class CTier extends Tier {
    @Override
    public String getTierName() {
        return "C";
    }
}
