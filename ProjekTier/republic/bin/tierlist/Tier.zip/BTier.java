package tierlist;

public class BTier extends Tier {
    @Override
    public String getTierName() {
        return "B";
    }
}
