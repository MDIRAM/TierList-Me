package tierlist;


public class DTier extends Tier {
    @Override
    public String getTierName() {
        return "D";
    }
}
